import fs from 'fs'
import path from 'path'

const postsDirectory = path.join(process.cwd(), 'data')

export async function getPosts(page = 1, limit = 6) {
  const fullPath = path.join(postsDirectory, 'posts.json')
  const fileContents = await fs.promises.readFile(fullPath, 'utf8')
  const data = JSON.parse(fileContents)
  const start = (page - 1) * limit
  const end = start + limit
  return data.posts.slice(start, end)
}

export async function getPostById(id: string) {
  const posts = await getPosts()
  return posts.find(post => post.id === id)
}

export async function getRelatedPosts(id: string) {
  const posts = await getPosts()
  return posts.filter(post => post.id !== id).slice(0, 2)
}

