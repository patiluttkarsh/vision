import { getPostById } from '../../../lib/api'
import Image from 'next/image'
import CommentSection from '../../components/CommentSection'
import RelatedPosts from '../../components/RelatedPosts'

export async function generateMetadata({ params }) {
  const post = await getPostById(params.id)
  return {
    title: post.title,
    description: post.description,
  }
}

export default async function BlogPost({ params }) {
  const post = await getPostById(params.id)

  return (
    <article className="max-w-3xl mx-auto animate-fade-in">
      <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
      <div className="mb-4 text-gray-600 dark:text-gray-400">
        <span>{post.author}</span> • <span>{post.date}</span>
      </div>
      <div className="relative h-64 mb-8">
        <Image
          src={post.thumbnail}
          alt={post.title}
          layout="fill"
          objectFit="cover"
          className="rounded-lg"
        />
      </div>
      <div className="prose dark:prose-invert max-w-none mb-8" dangerouslySetInnerHTML={{ __html: post.content }} />
      <CommentSection postId={post.id} />
      <RelatedPosts postId={post.id} />
    </article>
  )
}

